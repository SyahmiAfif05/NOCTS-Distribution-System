package com.azfar.nocts

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.LocalActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.azfar.nocts.ui.theme.NOCTSTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import androidx.compose.ui.platform.LocalContext

class ForgotPasswordActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NOCTSTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    ForgotPasswordScreen(Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun ForgotPasswordScreen(modifier: Modifier = Modifier) {
    var icNumber by remember { mutableStateOf("") }
    var showDialog by remember { mutableStateOf(false) }           // controls popup visibility
    var loading by remember { mutableStateOf(false) }              // progress while sending
    val activity = LocalActivity.current
    val context = LocalContext.current

    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }

    // Keep your brand color
    val customYellow = Color(0xFFD79A18)

    fun normalizeIC(input: String): String = input.filter { it.isDigit() } // strip dashes/spaces

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFECECEC))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Logo
            Image(
                painter = painterResource(id = R.drawable.onlylogo),
                contentDescription = "NOCTS Logo",
                modifier = Modifier
                    .height(250.dp)
                    .width(250.dp)
                    .offset(y = (-150).dp)
                    .align(Alignment.CenterHorizontally)
            )

            Text(
                text = "Forgot Password",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF101010),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .offset(y = (-150).dp)
                    .align(Alignment.CenterHorizontally)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = (-35).dp)
            ) {
                OutlinedTextField(
                    value = icNumber,
                    onValueChange = { icNumber = it },
                    label = { Text("MyKad Number") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(32.dp))

                // Reset Password Button
                Button(
                    onClick = {
                        val rawIC = icNumber.trim()
                        if (rawIC.isEmpty()) {
                            Toast.makeText(context, "Please enter your IC", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        loading = true
                        val ic = normalizeIC(rawIC)

                        // 1) Look up Firestore for IC -> recoveryEmail
                        db.collection("users")
                            .whereEqualTo("ic", ic) // Make sure you stored normalized IC at signup
                            .get()
                            .addOnSuccessListener { snapshot ->
                                if (snapshot.isEmpty) {
                                    loading = false
                                    Toast.makeText(context, "IC not registered", Toast.LENGTH_SHORT).show()
                                    return@addOnSuccessListener
                                }

                                val doc = snapshot.documents[0]
                                val recoveryEmail = doc.getString("recoveryEmail")

                                if (recoveryEmail.isNullOrBlank()) {
                                    loading = false
                                    Toast.makeText(context, "No recovery email on file for this IC", Toast.LENGTH_LONG).show()
                                    return@addOnSuccessListener
                                }

                                // 2) Send Firebase reset email
                                auth.sendPasswordResetEmail(recoveryEmail)
                                    .addOnSuccessListener {
                                        loading = false
                                        showDialog = true   // show your success popup
                                    }
                                    .addOnFailureListener { e ->
                                        loading = false
                                        Toast.makeText(
                                            context,
                                            "Failed to send reset email: ${e.message}",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                            }
                            .addOnFailureListener { e ->
                                loading = false
                                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = customYellow,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                ) {
                    if (loading) {
                        CircularProgressIndicator(
                            color = Color.Black,
                            modifier = Modifier.size(24.dp)
                        )
                    } else {
                        Text("Reset Password")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Back Button
                Button(
                    onClick = { activity?.finish() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = customYellow,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                ) {
                    Text("Back")
                }
            }
        }
    }

    // 🔹 Popup Dialog (shown after email sent)
    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Password Recovery") },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "Recovery steps have been sent to the email associated with this account.",
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Centered Continue Button
                    Button(
                        onClick = {
                            showDialog = false
                            // Optional: take user back to Login screen:
                            // (activity as? ComponentActivity)?.finish()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = customYellow,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier.fillMaxWidth(0.6f) // 60% width, centered
                    ) {
                        Text("Continue")
                    }
                }
            },
            confirmButton = {},
            dismissButton = {}
        )
    }
}

@Preview(showBackground = true)
@Composable
fun ForgotPasswordPreview() {
    NOCTSTheme {
        ForgotPasswordScreen()
    }
}
