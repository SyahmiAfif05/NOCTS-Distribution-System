package com.azfar.nocts

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.LocalActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.azfar.nocts.ui.theme.NOCTSTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SignupActivity2 : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NOCTSTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    SignupScreen2(Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun SignupScreen2(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val activity = LocalActivity.current

    // Get IC + Email passed from SignupActivity (already normalized IC)
    val icFromIntent = remember { (activity as? SignupActivity2)?.intent?.getStringExtra("IC") ?: "" }
    val emailFromIntent = remember { (activity as? SignupActivity2)?.intent?.getStringExtra("EMAIL") ?: "" }

    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }

    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var showDialog by remember { mutableStateOf(false) }

    val customYellow = Color(0xFFD79A18)

    fun internalEmailFromIC(ic: String) = "${ic}@mysubsidy.local"

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFECECEC)) // Light grey background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Logo
            Image(
                painter = painterResource(id = R.drawable.onlylogo),
                contentDescription = "NOCTS Logo",
                modifier = Modifier
                    .height(250.dp)
                    .width(250.dp)
                    .offset(y = (-150).dp)
                    .align(Alignment.CenterHorizontally)
            )

            Text(
                text = "Signup",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF101010),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .offset(y = (-150).dp)
                    .align(Alignment.CenterHorizontally)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = (-35).dp)
            ) {
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password (Minimum 8 characters)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )

                Spacer(modifier = Modifier.height(32.dp))

// 🔹 Signup Button
                Button(
                    onClick = {
                        val ic = icFromIntent
                        val email = emailFromIntent
                        if (ic.isEmpty() || email.isEmpty()) {
                            Toast.makeText(context, "Missing IC or Email. Go back and try again.", Toast.LENGTH_LONG).show()
                            return@Button
                        }
                        if (password.length < 8) {
                            Toast.makeText(context, "Password must be at least 8 characters", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        loading = true

                        // 1) Check duplicate IC
                        db.collection("users")
                            .whereEqualTo("ic", ic)
                            .limit(1)
                            .get()
                            .addOnSuccessListener { snapshot ->
                                if (!snapshot.isEmpty) {
                                    loading = false
                                    Toast.makeText(context, "This IC is already registered.", Toast.LENGTH_LONG).show()
                                    return@addOnSuccessListener
                                }

                                // 2) Create Firebase Auth user with the REAL recovery email
                                auth.createUserWithEmailAndPassword(email, password)
                                    .addOnSuccessListener { result ->
                                        val uid = result.user!!.uid

                                        // 3) Save profile to Firestore
                                        val userData = hashMapOf(
                                            "ic" to ic, // normalized digits-only IC
                                            "recoveryEmail" to email,
                                            "createdAt" to com.google.firebase.Timestamp.now()
                                        )

                                        db.collection("users").document(uid).set(userData)
                                            .addOnSuccessListener {
                                                loading = false
                                                showDialog = true
                                            }
                                            .addOnFailureListener { e ->
                                                loading = false
                                                Toast.makeText(
                                                    context,
                                                    "Failed to save user: ${e.message}",
                                                    Toast.LENGTH_LONG
                                                ).show()
                                            }
                                    }
                                    .addOnFailureListener { e ->
                                        loading = false
                                        Toast.makeText(
                                            context,
                                            "Signup failed: ${e.message}",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                            }
                            .addOnFailureListener { e ->
                                loading = false
                                Toast.makeText(context, "Error checking IC: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = customYellow,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier.fillMaxWidth().height(60.dp)
                ) {
                    if (loading) {
                        CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(24.dp))
                    } else {
                        Text("Continue")
                    }
                }


                Spacer(modifier = Modifier.height(12.dp))

                // 🔹 Back Button
                Button(
                    onClick = { activity?.finish() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = customYellow,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                ) {
                    Text("Back")
                }
            }
        }
    }

    // ✅ Success Popup (after account + Firestore saved)
    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Signup Successful") },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "Account created. Please log in using your IC and password.",
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    Button(
                        onClick = {
                            val intent = Intent(context, LoginActivity::class.java)
                            context.startActivity(intent)
                            (context as? ComponentActivity)?.finish()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = customYellow,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier.fillMaxWidth(0.6f)
                    ) {
                        Text("Continue")
                    }
                }
            },
            confirmButton = {},
            dismissButton = {}
        )
    }
}

@Preview(showBackground = true)
@Composable
fun SignupActivity2ScreenPreview() {
    NOCTSTheme {
        SignupScreen2()
    }
}


