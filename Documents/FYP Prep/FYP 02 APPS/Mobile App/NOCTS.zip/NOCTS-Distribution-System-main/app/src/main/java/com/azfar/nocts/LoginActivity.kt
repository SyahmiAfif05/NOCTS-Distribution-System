package com.azfar.nocts

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.LocalActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.azfar.nocts.ui.theme.NOCTSTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class LoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NOCTSTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    LoginScreen(Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun LoginScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val activity = LocalActivity.current

    // Firebase
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() } // optional, used if you want profile

    // State
    var myKad by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }

    // Helpers
    fun normalizeIC(input: String) = input.filter { it.isDigit() }
    fun internalEmailFromIC(ic: String) = "${ic}@mysubsidy.local"

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFECECEC)) // Light grey background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Logo Image
            Image(
                painter = painterResource(id = R.drawable.onlylogo),
                contentDescription = "NOCTS Logo",
                modifier = Modifier
                    .height(250.dp)
                    .width(250.dp)
                    .offset(y = (-150).dp)
                    .align(Alignment.CenterHorizontally)
            )

            Text(
                text = "Login",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF101010),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .offset(y = (-150).dp)
                    .align(Alignment.CenterHorizontally)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = (-35).dp)
            ) {
                OutlinedTextField(
                    value = myKad,
                    onValueChange = { myKad = it },
                    label = { Text("MyKad Number") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Forgot Password?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF101010),
                    modifier = Modifier
                        .align(Alignment.End)
                        .padding(end = 4.dp)
                        .clickable {
                            context.startActivity(Intent(context, ForgotPasswordActivity::class.java))
                        }
                )

                Spacer(modifier = Modifier.height(32.dp))

                val customYellow = Color(0xFFD79A18)

                // 🔹 Login Button
                // 🔹 Login Button
                Button(
                    onClick = {
                        val icNormalized = normalizeIC(myKad.trim())
                        val pwd = password

                        if (icNormalized.isEmpty()) {
                            Toast.makeText(context, "Please enter your MyKad (IC)", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (pwd.isEmpty()) {
                            Toast.makeText(context, "Please enter your password", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        loading = true

                        // 1) Look up the recovery email for this IC
                        db.collection("users").whereEqualTo("ic", icNormalized).limit(1).get()
                            .addOnSuccessListener { snapshot ->
                                if (snapshot.isEmpty) {
                                    loading = false
                                    Toast.makeText(context, "IC not registered", Toast.LENGTH_SHORT).show()
                                    return@addOnSuccessListener
                                }

                                val email = snapshot.documents[0].getString("recoveryEmail") ?: ""
                                if (email.isEmpty()) {
                                    loading = false
                                    Toast.makeText(context, "No email found for this IC", Toast.LENGTH_SHORT).show()
                                    return@addOnSuccessListener
                                }

                                // 2) Sign in with email + password
                                auth.signInWithEmailAndPassword(email, pwd)
                                    .addOnSuccessListener {
                                        loading = false
                                        Toast.makeText(context, "Login successful", Toast.LENGTH_SHORT).show()
                                        context.startActivity(Intent(context, LoginActivity2::class.java))
                                    }
                                    .addOnFailureListener { e ->
                                        loading = false
                                        Toast.makeText(context, "Login failed: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                            }
                            .addOnFailureListener { e ->
                                loading = false
                                Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = customYellow,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                ) {
                    if (loading) {
                        CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(24.dp))
                    } else {
                        Text("Login")
                    }
                }


                Spacer(modifier = Modifier.height(12.dp))

                // 🔹 Back Button
                Button(
                    onClick = { activity?.finish() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD79A18),
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                ) {
                    Text("Back")
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun LoginScreenPreview() {
    NOCTSTheme {
        LoginScreen()
    }
}


