NOCTS Distribution System (V1.0.0)

Changes made on (18-9-2025)
- Integrated database with login/signup and password recovery
- Ensured error handling for login/signup and password recovery functioned correctly
- Corrected UI element , where SignupActivity2 asked for PIN number, when it has been removed permanently from the system

